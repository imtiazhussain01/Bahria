
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head id="pageHead"><script type="text/javascript">
var aspireRootPath="https://cms.bahria.edu.pk/";
window.LiveSite=true;
window.AspireWebControls={};
</script><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /><title>
	Faculty Member - Bahria University
</title><link href="../../Content/Bundles/Aspire.min.css" rel="stylesheet" /><link rel="shortcut icon" href="../../favicon.ico" type="image/x-icon" /><link rel="apple-touch-icon" href="../../Images/apple-touch-icon.png" /><link rel="apple-touch-icon" sizes="57x57" href="../../Images/apple-touch-icon-57x57.png" /><link rel="apple-touch-icon" sizes="72x72" href="../../Images/apple-touch-icon-72x72.png" /><link rel="apple-touch-icon" sizes="76x76" href="../../Images/apple-touch-icon-76x76.png" /><link rel="apple-touch-icon" sizes="114x114" href="../../Images/apple-touch-icon-114x114.png" /><link rel="apple-touch-icon" sizes="120x120" href="../../Images/apple-touch-icon-120x120.png" /><link rel="apple-touch-icon" sizes="144x144" href="../../Images/apple-touch-icon-144x144.png" /><link rel="apple-touch-icon" sizes="152x152" href="../../Images/apple-touch-icon-152x152.png" /><link rel="apple-touch-icon" sizes="180x180" href="../../Images/apple-touch-icon-180x180.png" /><meta name="description" content="Campus Management System - Bahria University" /></head>
<body class="City">
	<form method="post" action="./Login.aspx" onsubmit="javascript:return WebForm_OnSubmit();" id="form1" autocomplete="off">
<div class="aspNetHidden">
<input type="hidden" name="__LASTFOCUS" id="__LASTFOCUS" value="" />
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="abvB10MmA4PgCTA1bagaaHOB6U5jSk91NC2gPq36WKZKowcOTd6sYk6BV4r+vmJ3R20kbFtQWfp8ZxFnMEYWt5BbkF2dhJrg4arbpB2ZUBxsvgTnqiF53oFBUUKSZXNB+ltrYXx88UlbsLT5ScHd6mWFu0+Tu5tf/pdn4FThvRlLPiaO9lc8BB+7jaYBbknxW97peuJA64oN9q/oiXYIcVCvzDb2M3+izjtbekk/dRWo0mmu718DV1YkMikxRPqddquHa7vVgzvcwUFnPsjbe3HZ0ufggHuOSHGFi2ag+dT64pACxg5vdRPbFg9eOBoPGjRAsyi1ebM/pa1q8CcSwdSETv49BHZlbgMYFkYcpYmjB6MFxMml95SywaDBo0J8SXevznj6jKb/q2B2dEj8ZqI+gA512InhXOJKKNgOYGerLN5v/gpEp0+614jcTD6iRq4zCTaGaU+JsJIEhXYBQ6QxIFC50V6KOlfMkXROJM8ETYY7aEgyBjvAP+ag8zQCEqAJOehfZfnHeumXH79aKpRAq9R2BI3tC7aKu67jabl/S9uXxH7KboqNUGhsBAeRTaqxWK4OZ1G0cssvvXodIvn9ny4GY9eNdubpkINPE2cPLOfDTKJFTughQC6CtqD+Ca+523RMiFGfj0Out04vtJYAKyi7w4+M4vjbZ4ATyj9ci/6LJSgB0vbC7/buJvuiJ6tCip5YIGfGCFGmzwHHmiPNsf/edIevdwEfTxTFRz3L2zPRtMlYGLvhE9YjguvzlXuoqb8lG1+EAII6kfqVkcYU6R1ESpGAi74bRlcr2A1c1VoH+jJNcqotVVCIZfWBK9FiZ67zlOwcDqdIV48eFimdZL+yMRf4CqIlI2vBH+XeCdapeeJwkGCbFbKPtpCarDPBhPHvLAvI7XJ0Sq/a7xRzV3y8QSBbFoIAN4is7mMiDQ5VlsqMUr7d4R/Y9n/onI2alLz4FUXrIQs30MsU/isPDJyiEgpZb8U13+LrY5+EZ8ebn08Y0vBxHtFI4DDag2+ryH1wLOLZk1c9iJGT8GFJNWfSvvSF5M1x9qhnrcftaZXHBpLyG817qqV/0mYEw1o49nQt7BUZvZMXiq8s521gbYFTd+6MceDDvhKg5+H3/RcrReUhAUxNQtPpqw+ulcJqngS3fzLTRevCyysP5QfLW1i5hSl5Kz5ebNllUqoF0rBpwg9x/lH+hpZ/5YJXvWGWL7XvbKQ1P/FrGF9h7/Pkc4s3KhxN+QP3CdkssWLAAp2UZ1Lv8sS4FwhgXmBGMVaDHzDh7VIyPESKmesKhz//mLoNhMInCHAnX8pzkwMuQvVMwFg1GIBEP+yDrVb1Lagcj9qIygI4oOuY8IGlurS2gvcy2emAmEyr8CH72aAJJViu3dnxry6MF4xpqeZzNRUpiZ040ZORGDnOma2Er+Na9saGu0W9yt1n9O3DEqHWTvUfM6CIvarCyyY8BBvO0c5YdlHngZC018+d9Bgk1qGfHYB8K+ua2EUuTlMEyYmdBzWvgWM5XMZxU4lCldnKlTKL1230u+YO/XB9u0S0JpAefMpJ8C2We1y3tt78ekoGqD6eMAmU4A5jLDoRg/ZQVz3qXuZG+vRFiKiCL2zxJR1liPRKzvpYwWRXZ8hMTihpMJu7q+mL/2+1VWpSLvMZQcigJDwO77BIP0U+PwxpaFSgs9HC5mn08AP19YkII8S0Uu2T3JmDBXqXNMipTfu4nuufFjX+S9CqsYljWmop8prufec/UZD1Q345VD1GUyWiT1Iqt2cfA55X82ptCnujsFvpNIgNpTOK3lWjHyTYCv8UjelM7IwgWd3GudEp14Y17yEL0rnhEFTz4pKayAUiErPFEd5YnWjUUs6JoDH5cAOI9LsmIc62caX/HYpy5321gQyeUS6rHvwCsnvecN8Wc0FIUfffVLf0OXHUjU2AmmKClAnTk8NmiJBuVTytOVo=" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form1'];
if (!theForm) {
    theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>



<script type="text/javascript">
//<![CDATA[
var __cultureInfo = {"name":"en-GB","numberFormat":{"CurrencyDecimalDigits":2,"CurrencyDecimalSeparator":".","IsReadOnly":false,"CurrencyGroupSizes":[3],"NumberGroupSizes":[3],"PercentGroupSizes":[3],"CurrencyGroupSeparator":",","CurrencySymbol":"£","NaNSymbol":"NaN","CurrencyNegativePattern":1,"NumberNegativePattern":1,"PercentPositivePattern":1,"PercentNegativePattern":1,"NegativeInfinitySymbol":"-∞","NegativeSign":"-","NumberDecimalDigits":2,"NumberDecimalSeparator":".","NumberGroupSeparator":",","CurrencyPositivePattern":0,"PositiveInfinitySymbol":"∞","PositiveSign":"+","PercentDecimalDigits":2,"PercentDecimalSeparator":".","PercentGroupSeparator":",","PercentSymbol":"%","PerMilleSymbol":"‰","NativeDigits":["0","1","2","3","4","5","6","7","8","9"],"DigitSubstitution":1},"dateTimeFormat":{"AMDesignator":"AM","Calendar":{"MinSupportedDateTime":"\/Date(-62135596800000)\/","MaxSupportedDateTime":"\/Date(253402282799999)\/","AlgorithmType":1,"CalendarType":1,"Eras":[1],"TwoDigitYearMax":2049,"IsReadOnly":false},"DateSeparator":"/","FirstDayOfWeek":1,"CalendarWeekRule":2,"FullDateTimePattern":"dddd, d MMMM yyyy h:mm:ss tt","LongDatePattern":"dddd, d MMMM yyyy","LongTimePattern":"h:mm:ss tt","MonthDayPattern":"d MMMM","PMDesignator":"PM","RFC1123Pattern":"ddd, dd MMM yyyy HH\u0027:\u0027mm\u0027:\u0027ss \u0027GMT\u0027","ShortDatePattern":"dd/MM/yyyy","ShortTimePattern":"h:mm tt","SortableDateTimePattern":"yyyy\u0027-\u0027MM\u0027-\u0027dd\u0027T\u0027HH\u0027:\u0027mm\u0027:\u0027ss","TimeSeparator":":","UniversalSortableDateTimePattern":"yyyy\u0027-\u0027MM\u0027-\u0027dd HH\u0027:\u0027mm\u0027:\u0027ss\u0027Z\u0027","YearMonthPattern":"MMMM yyyy","AbbreviatedDayNames":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"ShortestDayNames":["Su","Mo","Tu","We","Th","Fr","Sa"],"DayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"AbbreviatedMonthNames":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec",""],"MonthNames":["January","February","March","April","May","June","July","August","September","October","November","December",""],"IsReadOnly":false,"NativeCalendarName":"Gregorian Calendar","AbbreviatedMonthGenitiveNames":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec",""],"MonthGenitiveNames":["January","February","March","April","May","June","July","August","September","October","November","December",""]},"eras":[1,"A.D.",null,0]};//]]>
</script>

<script src="/bundles/MsAjaxJs?v=D6VN0fHlwFSIWjbVzi6mZyE9Ls-4LNrSSYVGRU46XF81" type="text/javascript"></script>
<script src="../../Scripts/Plugins/jquery/jquery-3.3.1.min.js" type="text/javascript"></script>
<script src="/bundles/WebFormsJs?v=N8tymL9KraMLGAMFuPycfH3pXe6uUlRXdhtYv8A_jUU1" type="text/javascript"></script>
<script src="../../Scripts/Bundles/Aspire.min.js" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
//]]>
</script>

<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="EE5284C3" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="LqX9UJfB01ofRe/aC524p6KiJzMTZ16PviAXnGeSUbk40YoMZ+lo5aLJDDXgseHnC8ZZBan/lU+xPdrw9IjZ5v16RKQqjBr1reNzelWgQnGvnnaPQBmKCPMec+eOCPaHmLaJiW/s7+UDwjbS0ScTjsg11mYxLlW98D1feE8MlmWD6tEYEeQJ/VR1HfWfEJag/9b9iYGlPG6pPrJkVKy4FF4wRIzEhrcUKoInmI5KfXa/crSSPYuZ9W/mDxzMIc+Ca6+G5KQm5rK9szPAX2Ek8c23xsVcG1tT4TDcehYfuPGU1JBNo9FScwWzedwnWWat8o4HdtBhI9tMJyjzuYoyhom3ODqY9YnlHtRFF9u4aD+FuW9/ZXg3a8U7W9JoX0R0Zz7csFOQ2Wct/yU5iT7TVXeRLgaxyqHUQARWgNO4GJNygHiHo9aOu/TkbFWA7UW3p6i/Jk+y7ZUyje3QiAHNd9mVn0Ej0/8LufOrVrBlI+2KBmKbiRz5UJHLRc7ID6Jz" />
</div>
		<noscript><meta http-equiv="Refresh" content="0;URL=../../NoJavascript.aspx?v=6QGpJbfvunsBgTsm7VjjJm6Jlil22WJIZtDuFySDrzYR2jyZT2WT1qsxqiUJe0emMoBGFhoTqNfNJnO%2fUp%2bluGMwKwq3mDJLdVQ84d5UeUGHPanZh0x%2fU%2bXK2LSPMr07GZjs4vf91PcJGEQgD9E%2bNQ%3d%3d" /></noscript>
		<script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ctl15', 'form1', ['tctl00$pageAlerts$up','pageAlerts_up'], [], [], 90, 'ctl00');
//]]>
</script>

		<div id="pageContainer">
			<header id="header" class="navbar navbar-fixed-top">
				<div class="container-fluid">
					<div class="navbar-header">
						
						<a href="../../Default.aspx" id="brandName" class="navbar-brand Name">Bahria University</a>
						<a href="../../Default.aspx" id="brandShortName" class="navbar-brand ShortName">Bahria University</a>
						<a href="../../Default.aspx" id="brandAlias" class="navbar-brand Alias">Bahria University</a>
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#AccountsNavbar">
							<span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
						</button>
					</div>
					<div class="collapse navbar-collapse" id="AccountsNavbar">
						
						
					</div>
				</div>
			</header>
			
			<div id="pageContent">
				
				
<div id="pageHeading">
	<h1 id="pageTitle_h1" class="text-center">
		
		Faculty Member
	</h1>
</div>

				<div class="container-fluid">
					<div id="pageAlerts_up">
	
		
	
</div>

					
	<div class="row" onkeypress="javascript:return WebForm_FireDefaultButton(event, &#39;BodyPH_btnLogin&#39;)" style="margin-top: 2%">
	
		<div class="col-md-4 col-md-offset-4">
			<div class="form-group">
				
			</div>
			<div class="form-group">
				<label for="BodyPH_tbUserName" class="control-label">Username:</label>
				<div class="input-group">
					<span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
					<input name="ctl00$BodyPH$tbUserName" type="text" maxlength="100" id="BodyPH_tbUserName" class="form-control" placeholder="Username" data-texttransform="None" data-maxlength="100" data-trimtext="True" />
				</div>
				<span data-val-controltovalidate="BodyPH_tbUserName" data-val-focusOnError="t" data-val-display="Dynamic" data-val-validationGroup="Login" id="BodyPH_ctl02" class="text-danger" data-requirederrormessage="This field is required." data-invaliddataerrormessage data-validationexpression data-allownull="False" data-highlightcssclass="has-error" data-val="true" data-val-evaluationfunction="CustomValidatorEvaluateIsValid" data-val-clientvalidationfunction="ValidateString" data-val-validateemptytext="true" style="display:none;"></span>
			</div>
			<div class="form-group">
				<label for="BodyPH_tbPassword" class="control-label">Password:</label>
				<div class="input-group">
					<span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
					<input name="ctl00$BodyPH$tbPassword" type="password" maxlength="100" id="BodyPH_tbPassword" class="form-control" placeholder="Password" data-texttransform="None" data-maxlength="100" data-trimtext="True" />
				</div>
				<span data-val-controltovalidate="BodyPH_tbPassword" data-val-focusOnError="t" data-val-display="Dynamic" data-val-validationGroup="Login" id="BodyPH_ctl04" class="text-danger" data-requirederrormessage="This field is required." data-invaliddataerrormessage data-validationexpression data-allownull="False" data-highlightcssclass="has-error" data-val="true" data-val-evaluationfunction="CustomValidatorEvaluateIsValid" data-val-clientvalidationfunction="ValidateString" data-val-validateemptytext="true" style="display:none;"></span>
			</div>
			<div class="form-group">
				<label for="BodyPH_ddlInstituteID" class="control-label">Institute:</label>
				<div class="input-group">
					<span class="input-group-addon"><span class="fa fa-university"></span></span>
					<select name="ctl00$BodyPH$ddlInstituteID" id="BodyPH_ddlInstituteID" class="form-control AspireDropDownList">
		<option selected="selected" value="">Select</option>
		<option value="13">Bahria University College of Nursing</option>
		<option value="10">Finishing School</option>
		<option value="12">Health Sciences Campus (Islamabad)</option>
		<option value="6">Health Sciences Campus (Karachi)</option>
		<option value="5">IPP (Karachi)</option>
		<option value="1">Islamabad E-8 Campus</option>
		<option value="9">Islamabad H-11 Campus</option>
		<option value="2">Karachi Campus</option>
		<option value="3">Lahore Campus</option>
		<option value="11">NATIONAL SCHOOL OF HYDROGRAPHY</option>
		<option value="4">NCMPR</option>
		<option value="14">ODL</option>
		<option value="8">PN Nursing College</option>
		<option value="7">PN School Of Logistics</option>

	</select>
				</div>
				<span data-val-controltovalidate="BodyPH_ddlInstituteID" data-val-focusOnError="t" data-val-display="Dynamic" data-val-validationGroup="Login" id="BodyPH_ctl06" class="text-danger" data-requirederrormessage="This field is required." data-invaliddataerrormessage data-validationexpression data-allownull="False" data-highlightcssclass="has-error" data-val="true" data-val-evaluationfunction="CustomValidatorEvaluateIsValid" data-val-clientvalidationfunction="ValidateString" data-val-validateemptytext="true" style="display:none;"></span>
			</div>
			
			<div class="form-group">
				<a onclick="return ButtonClick(this);" id="BodyPH_btnLogin" class="btn-block btn btn-primary" data-enabled="True" data-confirmmessagetitle="Confirm" data-confirmmessage="" data-disableonclick="True" data-onclientclick="" data-validationgroup="Login" data-causesvalidation="True" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$BodyPH$btnLogin&quot;, &quot;&quot;, true, &quot;Login&quot;, &quot;&quot;, false, true))">Sign In</a>
			</div>
		</div>
		
	
</div>
	<script type="text/javascript">
		deleteAllCookies();
	</script>

				</div>
			</div>
		</div>
		<footer id="footer">
			2026 © <a href="https://bahria.edu.pk/" target="_blank">Bahria University</a>
		</footer>
		<input type="hidden" name="ctl00$hfJsEnabled" id="hfJsEnabled" value="0" />
	

<script type="text/javascript">
//<![CDATA[
if(window.AspireWebControls.TextBoxRegister===undefined||window.AspireWebControls.TextBoxRegister===null)window.AspireWebControls.TextBoxRegister=[];
window.AspireWebControls.TextBoxRegister.push("BodyPH_tbUserName");if(window.AspireWebControls.TextBoxRegister===undefined||window.AspireWebControls.TextBoxRegister===null)window.AspireWebControls.TextBoxRegister=[];
window.AspireWebControls.TextBoxRegister.push("BodyPH_tbPassword");WebForm_AutoFocus('BodyPH_tbUserName');//]]>
</script>
</form>
</body>
</html>
